STACK 1
Para el stack 1, ejecute el codigo de app.py dandole en el icono de run (ESE SERA EL SERVIDOR)
para la parte del cliente, abre el client.html


STACK 2
Para el stack 2, vaya al archivo app.py dentro de la carpeta de stack 2, y en la terminal ejecute  
"uvicorn app:app --host 0.0.0.0 --port 8000", y en el navegador vaya al http://localhost:8000/
